-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 10. Jan 2018 um 23:13
-- Server-Version: 10.1.29-MariaDB
-- PHP-Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `onlinestore`
--
CREATE DATABASE IF NOT EXISTS `onlinestore` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `onlinestore`;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `article`
--

CREATE TABLE `article` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `category` varchar(255) NOT NULL,
  `picture` mediumblob,
  `price` decimal(15,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `article`
--

INSERT INTO `article` (`id`, `name`, `description`, `category`, `picture`, `price`) VALUES
(1, 'Devolved', 'Ins d-e stnt sup fem art', 'justo etiam pretium iaculis justo in hac habitasse platea dictumst', 0x68747470733a2f2f726f626f686173682e6f72672f7369746e616d616d65742e706e673f73697a653d3530783530267365743d73657431, '4.53'),
(2, 'bifurcated', 'Hemilaryngectomy', 'cum sociis natoque penatibus et magnis dis parturient montes nascetur ridiculus mus vivamus vestibulum sagittis sapien', 0x68747470733a2f2f726f626f686173682e6f72672f7665726f657471756964656d2e6a70673f73697a653d3530783530267365743d73657431, '5.88'),
(3, 'Fundamental', 'Transab sm bowel endosc', 'nullam molestie nibh in lectus pellentesque at nulla suspendisse potenti cras in purus eu magna', 0x68747470733a2f2f726f626f686173682e6f72672f726572756d75746e656d6f2e626d703f73697a653d3530783530267365743d73657431, '10.41'),
(4, 'Networked', 'Incision of lung', 'non mauris morbi non lectus aliquam sit amet diam in magna bibendum imperdiet nullam orci pede venenatis', 0x68747470733a2f2f726f626f686173682e6f72672f76656c69747365646f666669636969732e6a70673f73697a653d3530783530267365743d73657431, '7.02'),
(5, 'local', 'Lap bil dir ing hrn-grft', 'nisl nunc nisl duis bibendum felis sed interdum venenatis turpis enim blandit mi in porttitor pede justo eu', 0x68747470733a2f2f726f626f686173682e6f72672f696c6c756d6e6968696c6573742e706e673f73697a653d3530783530267365743d73657431, '11.32'),
(6, 'projection', 'Destruct-knee lesion NEC', 'aliquam non mauris morbi non lectus aliquam sit amet diam in magna bibendum imperdiet nullam orci pede venenatis non sodales', 0x68747470733a2f2f726f626f686173682e6f72672f646f6c6f726573636f6e73657175617475726e617475732e626d703f73697a653d3530783530267365743d73657431, '2.60'),
(7, 'Multi-tiered', 'Adjust lid position NEC', 'molestie lorem quisque ut erat curabitur gravida nisi at nibh in hac habitasse', 0x68747470733a2f2f726f626f686173682e6f72672f616e696d6973756e74636f72706f7269732e706e673f73697a653d3530783530267365743d73657431, '16.99'),
(8, 'project', 'Lap bi dr/ind ing hrn-gr', 'aliquam non mauris morbi non lectus aliquam sit amet diam in magna bibendum imperdiet nullam orci pede venenatis non', 0x68747470733a2f2f726f626f686173682e6f72672f726570656c6c6174646f6c6f726570726f766964656e742e6a70673f73697a653d3530783530267365743d73657431, '4.96'),
(9, 'Customer-focused', 'Manual muscle funct test', 'sodales sed tincidunt eu felis fusce posuere felis sed lacus morbi sem', 0x68747470733a2f2f726f626f686173682e6f72672f65747574717561652e706e673f73697a653d3530783530267365743d73657431, '6.79'),
(10, 'Innovative', 'Emphysema bleb plication', 'faucibus orci luctus et ultrices posuere cubilia curae nulla dapibus', 0x68747470733a2f2f726f626f686173682e6f72672f646f6c6f72656d61696f7265736f7074696f2e6a70673f73697a653d3530783530267365743d73657431, '4.38'),
(11, 'directional', 'Thorac total exc thymus', 'turpis integer aliquet massa id lobortis convallis tortor risus dapibus augue vel accumsan tellus nisi', 0x68747470733a2f2f726f626f686173682e6f72672f746f74616d657373656f64696f2e6a70673f73697a653d3530783530267365743d73657431, '19.82'),
(12, 'Integrated', 'Mid forceps op NEC', 'bibendum imperdiet nullam orci pede venenatis non sodales sed tincidunt eu felis fusce posuere felis sed lacus morbi', 0x68747470733a2f2f726f626f686173682e6f72672f65756d6561706572666572656e6469732e6a70673f73697a653d3530783530267365743d73657431, '16.26'),
(13, 'User-centric', 'Pacemaker impedance chck', 'et ultrices posuere cubilia curae duis faucibus accumsan odio curabitur convallis duis consequat dui', 0x68747470733a2f2f726f626f686173682e6f72672f6574646f6c6f726569642e6a70673f73697a653d3530783530267365743d73657431, '3.39'),
(14, 'standardization', 'Oth rad/uln repair/plast', 'eleifend pede libero quis orci nullam molestie nibh in lectus pellentesque at nulla suspendisse potenti cras in purus eu magna', 0x68747470733a2f2f726f626f686173682e6f72672f6c61626f72696f73616d65747072616573656e7469756d2e6a70673f73697a653d3530783530267365743d73657431, '16.94'),
(15, 'neutral', 'Excision of shoulder NEC', 'vestibulum velit id pretium iaculis diam erat fermentum justo nec condimentum neque sapien placerat ante nulla justo aliquam quis turpis', 0x68747470733a2f2f726f626f686173682e6f72672f76656c697465747175692e706e673f73697a653d3530783530267365743d73657431, '5.53'),
(16, 'fault-tolerant', 'Radical maxillary antrot', 'sit amet cursus id turpis integer aliquet massa id lobortis convallis', 0x68747470733a2f2f726f626f686173682e6f72672f6574646f6c6f7265737665726f2e626d703f73697a653d3530783530267365743d73657431, '15.85'),
(17, 'circuit', 'Comb alcohol/drug rehab', 'eget elit sodales scelerisque mauris sit amet eros suspendisse accumsan tortor quis turpis sed ante vivamus tortor', 0x68747470733a2f2f726f626f686173682e6f72672f6e65736369756e747265696369656e64697371756964656d2e6a70673f73697a653d3530783530267365743d73657431, '17.50'),
(18, 'holistic', 'Ophthalmoscopy', 'ut tellus nulla ut erat id mauris vulputate elementum nullam varius nulla facilisi', 0x68747470733a2f2f726f626f686173682e6f72672f7072616573656e7469756d7365717569717569612e626d703f73697a653d3530783530267365743d73657431, '16.47'),
(19, 'Optimized', 'DIEP flap, free', 'enim blandit mi in porttitor pede justo eu massa donec dapibus duis at', 0x68747470733a2f2f726f626f686173682e6f72672f6173706572696f726573657473657175692e626d703f73697a653d3530783530267365743d73657431, '14.69'),
(20, 'encryption', 'Closed brain biopsy', 'eleifend pede libero quis orci nullam molestie nibh in lectus pellentesque at nulla suspendisse potenti', 0x68747470733a2f2f726f626f686173682e6f72672f6e6f6269736574717561732e6a70673f73697a653d3530783530267365743d73657431, '16.29');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `purchase`
--

CREATE TABLE `purchase` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `purchase_item`
--

CREATE TABLE `purchase_item` (
  `purchase_id` int(11) NOT NULL,
  `article_id` int(11) NOT NULL,
  `date_of_purchase` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `number_of_items` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `firstname` varchar(191) NOT NULL,
  `lastname` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `birthday` date NOT NULL,
  `street` varchar(191) NOT NULL,
  `postcode` varchar(12) NOT NULL,
  `state` varchar(191) NOT NULL,
  `country` varchar(191) NOT NULL,
  `username` varchar(191) NOT NULL,
  `password` varchar(191) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `user`
--

INSERT INTO `user` (`id`, `firstname`, `lastname`, `email`, `birthday`, `street`, `postcode`, `state`, `country`, `username`, `password`, `created_at`, `updated_at`) VALUES
(8, '', '', 'Bill@Billy.de', '0000-00-00', '', '', '', '', 'Bill', '$2y$14$/XJavz7Y0.jgtD03GKVHXef93R0nbzZbl9f/RS.kr/ECo1N9i9aLO', '2017-12-25 22:57:35', '2017-12-25 22:57:35'),
(9, '', '', '1234@1234.de', '0000-00-00', '', '', '', '', 'BillyNewman', '$2y$14$FfE7M8LGbkvPM2LPkL7LUu68Z1Vu1o2T4UbwHSnda.rlxxdDLaWgm', '2017-12-25 22:58:08', '2017-12-25 22:58:08'),
(10, '', '', 'lol@lol.de', '0000-00-00', '', '', '', '', 'mani', '$2y$14$0G6lJLMRw/hZNpbISlLOGeniyx8yONpxxUq7KasObqxgBFVex1/Hi', '2017-12-25 22:59:31', '2017-12-25 22:59:31'),
(15, '', '', 'admin@admin.de', '0000-00-00', '', '', '', '', 'Neax', '$2y$14$ZXv/yFoqRD0gsh1mgylAdeh5KtrKFQsXf3Gp507/Ve9q0igiEQ8N2', '2017-12-26 03:58:08', '2017-12-26 03:58:20'),
(16, '', '', 'testteee@testteee.de', '0000-00-00', '', '', '', '', 'testteee', '$2y$14$5tJ4EHbOYuLl8s0s/29QaO4PjSw9B2pleMIjp0VevJKYu/wZ.g0qu', '2017-12-26 04:24:03', '2017-12-26 04:24:51'),
(17, '', '', 'test@test.test', '0000-00-00', '', '', '', '', 'Test', '$2y$14$XN4MwMqEhEbvFj1Z0ywVteWk792QcOcjxn3Sz6eiYdGJW6XH8vt1y', '2017-12-26 04:25:38', '2017-12-26 04:25:38');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `purchase`
--
ALTER TABLE `purchase`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `purchase_item`
--
ALTER TABLE `purchase_item`
  ADD PRIMARY KEY (`purchase_id`,`article_id`);

--
-- Indizes für die Tabelle `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`,`username`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `article`
--
ALTER TABLE `article`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT für Tabelle `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
